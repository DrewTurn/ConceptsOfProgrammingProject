download conceptsProject file and only that file to a ide that can run java input the data into foo.txt to have it run throught the scanner or parser then run from java ide

Jonathan Turner
Jose Trevino
