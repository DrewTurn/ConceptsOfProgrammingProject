# ConceptsOfProgrammingProject
to run it input the data into foo.txt
then run from java ide and make sure the line on 201 containts the file path to foo.txt
there is an attached screenshot that shows the output of the file
